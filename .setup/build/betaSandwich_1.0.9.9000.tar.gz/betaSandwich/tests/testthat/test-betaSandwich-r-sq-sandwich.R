## ---- test-betaSandwich-r-sq-sandwich
lapply(
  X = 1,
  FUN = function(i,
                 text,
                 tol) {
    message(text)

    set.seed(42)

    if (!identical(Sys.getenv("NOT_CRAN"), "true") && !interactive()) {
      message("CRAN: tests skipped.")
      # nolint start
      return(invisible(NULL))
      # nolint end
    }

    testthat::test_that(
      paste(text, "mvn", "multiple regression"),
      {
        testthat::skip_on_cran()
        if (!exists("nas1982")) {
          try(
            data(
              "nas1982",
              package = "betaSandwich"
            ),
            silent = TRUE
          )
        }
        df <- nas1982
        object <- lm(QUALITY ~ NARTIC + PCTGRT + PCTSUPP, data = df)
        ############################################################
        # coverage #################################################
        ############################################################
        lm_process <- .ProcessLM(object)
        .JacVechSigmaWRTTheta(
          beta = lm_process$beta,
          sigmacapx = lm_process$sigmacap[
            2:lm_process$k,
            2:lm_process$k,
            drop = TRUE
          ],
          q = lm_process$q,
          p = lm_process$p,
          rsq = NULL
        )
        ############################################################
        r_sq <- summary(object)$r.squared
        adj <- summary(object)$adj.r.squared
        mvn <- RSqSandwich(BetaN(object))
        testthat::expect_true(
          all(
            abs(
              c(
                r_sq,
                adj
              ) - coef(mvn)
            ) <= tol
          )
        )
        testthat::expect_true(
          all(
            abs(
              summary(mvn)[, "est"] - coef(mvn)
            ) <= tol
          )
        )
      }
    )
    testthat::test_that(
      paste(text, "adf", "multiple regression"),
      {
        testthat::skip_on_cran()
        if (!exists("nas1982")) {
          try(
            data(
              "nas1982",
              package = "betaSandwich"
            ),
            silent = TRUE
          )
        }
        df <- nas1982
        object <- lm(QUALITY ~ NARTIC + PCTGRT + PCTSUPP, data = df)
        r_sq <- summary(object)$r.squared
        adj <- summary(object)$adj.r.squared
        adf <- RSqSandwich(BetaADF(object))
        testthat::expect_true(
          all(
            abs(
              c(
                r_sq,
                adj
              ) - coef(adf)
            ) <= tol
          )
        )
        testthat::expect_true(
          all(
            abs(
              summary(adf)[, "est"] - coef(adf)
            ) <= tol
          )
        )
      }
    )
    testthat::test_that(
      paste(text, "hc3", "multiple regression"),
      {
        testthat::skip_on_cran()
        if (!exists("nas1982")) {
          try(
            data(
              "nas1982",
              package = "betaSandwich"
            ),
            silent = TRUE
          )
        }
        df <- nas1982
        object <- lm(QUALITY ~ NARTIC + PCTGRT + PCTSUPP, data = df)
        r_sq <- summary(object)$r.squared
        adj <- summary(object)$adj.r.squared
        hc3 <- RSqSandwich(BetaHC(object))
        testthat::expect_true(
          all(
            abs(
              c(
                r_sq,
                adj
              ) - coef(hc3)
            ) <= tol
          )
        )
        testthat::expect_true(
          all(
            abs(
              summary(hc3)[, "est"] - coef(hc3)
            ) <= tol
          )
        )
      }
    )
    testthat::test_that(
      paste(text, "mvn", "simple regression"),
      {
        testthat::skip_on_cran()
        if (!exists("nas1982")) {
          try(
            data(
              "nas1982",
              package = "betaSandwich"
            ),
            silent = TRUE
          )
        }
        df <- nas1982
        object <- lm(QUALITY ~ NARTIC, data = df)
        r_sq <- summary(object)$r.squared
        adj <- summary(object)$adj.r.squared
        mvn <- RSqSandwich(BetaN(object))
        testthat::expect_true(
          all(
            abs(
              c(
                r_sq,
                adj
              ) - coef(mvn)
            ) <= tol
          )
        )
        testthat::expect_true(
          all(
            abs(
              summary(mvn)[, "est"] - coef(mvn)
            ) <= tol
          )
        )
      }
    )
    testthat::test_that(
      paste(text, "adf", "simple regression"),
      {
        testthat::skip_on_cran()
        if (!exists("nas1982")) {
          try(
            data(
              "nas1982",
              package = "betaSandwich"
            ),
            silent = TRUE
          )
        }
        df <- nas1982
        object <- lm(QUALITY ~ NARTIC, data = df)
        r_sq <- summary(object)$r.squared
        adj <- summary(object)$adj.r.squared
        adf <- RSqSandwich(BetaADF(object))
        testthat::expect_true(
          all(
            abs(
              c(
                r_sq,
                adj
              ) - coef(adf)
            ) <= tol
          )
        )
        testthat::expect_true(
          all(
            abs(
              summary(adf)[, "est"] - coef(adf)
            ) <= tol
          )
        )
      }
    )
    testthat::test_that(
      paste(text, "hc3", "simple regression"),
      {
        testthat::skip_on_cran()
        if (!exists("nas1982")) {
          try(
            data(
              "nas1982",
              package = "betaSandwich"
            ),
            silent = TRUE
          )
        }
        df <- nas1982
        object <- lm(QUALITY ~ NARTIC, data = df)
        r_sq <- summary(object)$r.squared
        adj <- summary(object)$adj.r.squared
        hc3 <- RSqSandwich(BetaHC(object))
        testthat::expect_true(
          all(
            abs(
              c(
                r_sq,
                adj
              ) - coef(hc3)
            ) <= tol
          )
        )
        testthat::expect_true(
          all(
            abs(
              summary(hc3)[, "est"] - coef(hc3)
            ) <= tol
          )
        )
      }
    )
  },
  text = "test-betaSandwich-r-sq-sandwich",
  tol = 0.0001
)
