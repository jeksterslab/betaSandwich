# betaSandwich 1.0.7

## Patch

* Minor documentation edits.

# betaSandwich 1.0.6

## Patch

* Minor documentation edits.

# betaSandwich 1.0.5

## Patch

* Added degrees of freedom to the table of results.

# betaSandwich 1.0.4

## Patch

* Added the `DiffBetaSandwich()` and the `RSqBetaSandwich()` functions.

# betaSandwich 1.0.3

## Patch

* Added the `BetaADF()` function.

# betaSandwich 1.0.2

## Patch

* Factor variables are dummy coded.

# betaSandwich 1.0.1

## Patch

* Added the `nas1982` data set.
* Minor edits to methods.

# betaSandwich 1.0.0

## Major

* And so it begins.
