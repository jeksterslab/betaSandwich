# betaSandwich 1.0.4

* Added the `DiffBetaSandwich()` and the `RSqBetaSandwich()` functions.

# betaSandwich 1.0.3

## Patch

* Added the `BetaADF()` function.

# betaSandwich 1.0.2

## Patch

* Factor variables are dummy coded.

# betaSandwich 1.0.1

## Patch

* Added the `nas1982` data set.
* Minor edits to methods.

# betaSandwich 1.0.0

## Major

* And so it begins.
