#' Add environment tokens here.
#'
#' tokens <- c(
#'   KEY1 = "VALUE1",
#'   KEY2 = "VALUE2"
#' )
#'
if (git_user == "ijapesigan") {
  tokens <- c(
    GITHUB_PAT = "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", # nolint
    DOCKER_HUB_ACCESS_TOKEN = "dckr_pat_qhw2hVVuFCs2UIymgHOsPvVzDyM", # nolint
    QUARTO_PUB_AUTH_TOKEN = "qpa_upJIL7psR9SABtayhdsNF6IOmK4gFyoIDE87itZfkiHbNNCuTlKRKN92zQBSbJyP" # nolint
  )
}
if (git_user == "jeksterslab") {
  tokens <- c(
    GITHUB_PAT = "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", # nolint
    DOCKER_HUB_ACCESS_TOKEN = "dckr_pat_hAZA0dJ2GQU55r5IjALIRx1NzdY", # nolint
    QUARTO_PUB_AUTH_TOKEN = "qpa_TzIkBbrZdu3fPgErfV1edwOHD4OaVeHEJRnbXT4FrJuDzxZjKsLzgCTJulFVAcdv" # nolint
  )
}
if (git_user == "sigmaresearch100") {
  tokens <- c(
    GITHUB_PAT = "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", # nolint
    DOCKER_HUB_ACCESS_TOKEN = "dckr_pat_Al7uYNmmLcPrsVpSpaqv9i7tQPE", # nolint
    QUARTO_PUB_AUTH_TOKEN = "qpa_kjyolEakjA0iQ4jLP5x9v6KwQzq01ZzWuOMQbvZeCubQOp5a7VnV9YfwJVc2KDcI" # nolint
  )
}
